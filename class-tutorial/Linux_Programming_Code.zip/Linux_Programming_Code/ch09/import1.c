/*
   This is an important file for managing the project.
   It implements the canoncial "Hello World" program.
*/

#include <stdlib.h>
#include <stdio.h>

int main()
{
    printf("Hello World\n");
    exit (EXIT_SUCCESS);
}
 