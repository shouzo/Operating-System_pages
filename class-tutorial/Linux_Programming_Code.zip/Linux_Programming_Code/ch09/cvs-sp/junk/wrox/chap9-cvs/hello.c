#include <stdlib.h>
#include <stdio.h>

int main()
{
    printf("Hello World\n");
    printf("Have a nice day\n");
    exit (EXIT_SUCCESS);
}
